export const primaryGrad = [

  "rgba(170, 255, 251, 0.5)",
  "rgba(78, 67, 255, 0.57)",
  "rgba(137, 129, 254, 0.47)",
  "#fbfbfb",
  "#fbfbfb",
  "#fbfbfb",
  "#fbfbfb",
  // "#ffffff",
  // "#ffffff",
  // "#ffffff",
  // "#ffffff",

  // "rgba(90, 67, 255, 0.97)",
  // "rgba(78, 67, 255, 0.97)",
  // "rgba(255, 255, 255, 0.2)",

  // "rgba(170, 255, 251, 0.5)",
  // "rgba(78, 67, 255, 0.87)",
  // "rgba(137, 129, 254, 0.87)",
];
